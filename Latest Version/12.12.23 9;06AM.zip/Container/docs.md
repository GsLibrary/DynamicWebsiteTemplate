If You Are Using Replit.com Remove dotenv
and Use The Built In Secrets Function
and Replace process.env.SECRET With
process.env['SECRET']

-- -- -- -- -- 

