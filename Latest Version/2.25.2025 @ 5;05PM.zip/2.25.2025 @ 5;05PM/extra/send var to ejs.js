On Server.js
res.render('page', {VARIABLE: VALUE});

On .ejs
<%= VARIABLE %>